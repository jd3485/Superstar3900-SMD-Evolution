# Ripresa Superstar 3900 SMD Evolution - V1.1

**Allega lo ZIP cumulativo V1.1** nella nuova chat, contiene tutto V1.0 dentro `09_Archivi_Precedenti`.

Avanzamento STIMATO: **20.99% -> 21%**. Non corrisponde a collaudo o fabbricabilita.

Specifiche: 270 RX incluse 6 bande + alfa su interruttore indipendente, CH9, AM/FM/USB/LSB/CW, PA (solo audio), wattmeter, ROS, ATU, display, PCB prevalentemente SMD; TX limitata a frequenze/modi conformi.

Risultati nuovi: foglio KiCad DRAFT eFuse TPS26600PWPT nel percorso `04_KiCad/Sorgenti_Protezione_Ingresso_V1.1`, con `Netlist_Intenzionale_TPS26600_V1.1.csv`; alimenta `BUCK_VIN_PROTECTED` che entra nel buck TPS54202 V1.0. R200=365k, R201=16.2k, R202=30.1k, R203=8.2k, C201=22nF; nominale UVLO=10.57V OVP=16.26V ILIM=1.46A (SOLO CALCOLO).

**DIVIETO ASSOLUTO SCHEMA:** non collegare EFUSE_RTN a GND_MAIN; disattiva la protezione reverse.

CW/PA introdotti nei requisiti `01_Specifiche/CW_PA_Requisiti_V1.1.md`, NON implementati. PA deve bloccare TX RF; CW TX resta disabilitato salvo verifica legale.

Front-end presenta F200 TBD, D200 DNP (TVS non scelto), C200/C202 candidate e segnali fault da finalizzare. Nessun KiCad ERC/DRC, SPICE o misure hardware; PCB non esiste. TCXO pin10 e footprint ancora BLOCCANTI.

Passi successivi: (1) verificare modello esatto TCXO, (2) qualificare fuse/TVS e opzioni eFuse, (3) con KiCad nativo ERC e netlist, (4) simulazioni transient/EMI, (5) connettere schemi gerarchici 13.8V front-end + buck + LDO, (6) SPI, RX, TX, ATU e strumenti.

Non inviare a PCBWay fino a validazione e layout conclusi.
