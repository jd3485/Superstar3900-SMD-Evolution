# Cronologia revisioni — cumulativa

## V0.2 — 2026-11-06 — Primo studio RF/PLL e test sistema
- Aggiunto studio architettura ricezione supereterodina e sintesi ADF4351 Integer-N con riferimento 12,8MHz e prima FI 10,695MHz.
- Generata tabella completa PLL 270 posizioni (`Tabella_PLL_270_Integer_N.csv`) con frequenza LO, VCO, INT/FRAC, errori calcolati.
- Creato prototipo di modello di controllo CH9, ALFA, modalità, TX fail-closed e modello budget rumore Friis; suite test a 4 script eseguite con PASS.
- Registrati componenti candidati con stato NON APPROVATO, checklist di convalida, piano PCBWay, diagramma blocchi SVG/DOT e registri di rischio.
- Nessun circuito KiCad, SPICE/EM reale, ERC/DRC o prova di laboratorio in questa versione.

## V0.1.1 — 2026-11-06 — Struttura di continuità e manualistica
- Copiati integralmente i contenuti tecnici di V0.1.
- Aggiunti: `STATO_PROGETTO.md`, `RIPRENDI_IN_UNA_NUOVA_CHAT.md`, `REGISTRO_DECISIONI.md`, questo registro revisioni, indice master dei manuali, cinque schemi di struttura dei fascicoli, tabella tracciabilità requisiti e procedura di rilascio.
- Rieseguito il test del piano frequenze: PASS.
- Nessuna topologia elettronica nuova, nessuna simulazione RF, nessun file KiCad o output PCB prodotto in questa revisione.

## V0.1 — 2026-11-06 — Avvio tecnico
- Capitolo requisiti preliminari, modello 270 frequenze, tabella CSV, test automatici del modello, registro preliminare verifiche, note KiCad e produzione.

## V0.3 - 2026-11-06
- Pinout ADF4351 32+EP verificato da datasheet ufficiale e proposta reti di controllo/alimentazione.
- Nuova BOM PLL/LO **candidata**, non idonea all'ordine.
- Modellato filtro LO 7 poli con matrici ABCD e Monte Carlo; grafico, CSV, JSON, netlist ngspice NON eseguita.
- 2 suite test aggiunte, per un totale di 6.
- Nuovi disegni e dossier Fase 2; archivi precedenti V0.1, V0.1.1 e V0.2 conservati integralmente come file delle versioni.

## V0.4 - 2026-11-06
- Aggiunto modello linearizzato CPLF, analisi 4.000 casi di sensibilita con grafiche e file di verifica.
- Candidati filtro d'anello (C1 6.8nF, R2 1.2k, C2 120nF, R3 270ohm, C3 4.7nF).
- Scartato PHA-1+ (min dichiarato 50MHz) per LO 36-39MHz; candidato ADL5611 (30MHz min), P1dB basso a 30MHz attentamente considerato.
- Proposta pad regolabili 50ohm, TCXO 12,8MHz candidati.
- Nessuno schema KiCad/ERC, nessun PCB e nessuna misura fisica; non producibile.

## V0.5 - 2026-11-06
- Confronto ADF4351 e TI LMX2572 limitato al contributo bianco normalizzato in banda; differenza calcolata 15.01 dB, NON valore di phase noise totale.
- Nuovo elenco esatto dei 270 setpoint PLL LMX2572 Integer-N, nuovo script di riproduzione e test regressivi.
- Esempio mixing reciproco e piano misure per sensibilita'/dinamica RX.
- LMX2572 promosso a candidato, filtro loop V0.4 ADF4351 mantenuto ma marcato NON trasferibile.
- Dossier V0.5 PDF; tutti gli ZIP precedenti preservati, incluso V0.4.

## V0.6 - 2026-11-06
- Aggiunto studio filtro loop 3° ordine LMX2572 (valori non produzione), test 4.000 campioni e codice ripetibile.
- Nuova pinmap TI 40 pin+DAP e schema funzionale, BOM candidata, TCXO TXC 12.8MHz.
- Studio cambio core VCO3/VCO4 sulla gamma 270 frequenze, stato lock e interlock TX.
- Manuale tecnico e gestionale aggiornati. Nessuno schematico KiCad/PCB/gerber prodotto.


## V0.7 - 2026-11-06
- Primo documento `.kicad_sch` di studio, simbolo 40+1 e primi 5 passivi filtro loop; pin map e libreria custom.
- Correzione documentata bypass TI per pin 3 e 27 rispetto a V0.6.
- Controlli struttura Python, non KiCad ERC.
- Note manualistiche, PDF tecnico, anteprima SVG.


## V0.8 - 2026-11-06
- Inseriti fisicamente nello schema KiCad bozza 6 bypass VCC (0R + 1uF), 7 condensatori su nodi Vreg/Vref/Vbias e 10uF sul rail comune.
- Rete 3V3 proveniente da LDO esterno ancora da progettare; non dichiarato un circuito alimentatore completo.
- Aggiunti controllo strutturale riproducibile, audit netlist logica e stima avanzamento 18% con pesi.
- NON effettuati ERC, DRC o misure, non ordinarlo a PCBWay.

## V0.9 - 2026-11-06
- Aggiunti 2 LDO 3.3V SMD separati, bypass 100n ai sei Vcc LMX2572, TCXO TXC con R serie e C di accoppiamento.
- Corretto pin OSCinM: esplicito NC per configurazione single-ended, software R5 da definire.
- Schema KiCad solo DRAFT senza ERC; footprint TCXO non validato; preregolatore 5V non presente.
- Aggiunti test, BOM, nuovo dossier e metodo avanzamento.

## V1.0 - 2026-11-06
- Creato foglio KiCad separato BUCK TPS54202 (6 pin DDC) basato su Figura 7-1 datasheet TI.
- Valori TI EVM, distinta componenti con codici candidati, rete nominativa pin-pin e script di verifica.
- Documentato chiaramente che protezioni input e integrazione non sono approvate; Vout ideale circa 5.077V.
- Nessuna PCB, ERC, DRC o simulazione SPICE; conservato archivio V0.9 per ripresa.


## V1.1 - 2026-11-06
- eFuse protezione front-end 13.8V ausiliario (schema, BOM, netlist, modelli statici).
- Requisiti ufficiali CW e PA con verifiche future e blocco TX in PA.
- Percentuale stimata 20.99% (arrotondata 21%); non incremento hardware.
