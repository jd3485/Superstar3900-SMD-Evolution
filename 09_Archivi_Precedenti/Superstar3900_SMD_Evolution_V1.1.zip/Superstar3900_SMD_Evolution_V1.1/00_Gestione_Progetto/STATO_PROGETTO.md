# Stato del progetto - V0.8 (2026-11-06)

**Avanzamento complessivo stimato: 18%. STATO: NON FABBRICABILE.**

- Bozza schema LMX2572 ampliata con bypass locali per 6 VCC e 7 Vref/Vreg/Vbias.
- Il pannello, RX, TX, accordatore, firmware definitivo, alimentatore LDO e front-end non sono progettati a livello di schema finale.
- Non abbiamo KiCad CLI in questo ambiente: ERC e netlist ancora DA ESEGUIRE.
- PCB e Gerber non esistono. Test solo strutturali e numerici.
- La revisione resta studiata ma non approvata per montaggio.

Dettaglio dei pesi: `AVANZAMENTO_STIMATO_V0.8.csv`.

## Stato V0.9
Avanzamento stimato 19%, blocchi: preregolatore 13.8V -> 5V, pin10 TCXO, footprint, ERC, circuito SPI, RF/LO, RX/TX/ATU/firmware. Il modulo resta non fabbricabile.


## Stato aggiornato V1.1
Avanzamento complessivo **20.99% -> 21% stimato**. eFuse schematico in bozza, Cw/PA requisiti formalizzati, front-end non collaudato. RTN e GND separati. F200 e D200 non qualificati. No ERC/DRC, no PCB/firmware definitivo.
