# Registro decisioni (cumulativo)

| ID | Decisione | Stato | Motivo / Vincolo | Revisione |
|---|---|---|---|---|
| DEC-001 | Ricostruzione concettuale Superstar 3900 prevalentemente SMD | Confermata | Nuova radio con carattere vintage | V0.1 |
| DEC-002 | AM, FM, USB, LSB | Confermata | Continuità funzionale dell'originale | V0.1 |
| DEC-003 | Sei bande A–F, 270 frequenze RX | Confermata | 6 × (40+5) | V0.1 |
| DEC-004 | Interruttore ALFA fisico separato | Confermata | Usabilità vintage; Alfa su 3/7/11/15/19 | V0.1 |
| DEC-005 | Interruttore CH9 prioritario | Confermata | Richiamo 27,065 MHz AM; ripristino dello stato | V0.1 |
| DEC-006 | Ricevitore molto sensibile, selettivo e silenzioso | Confermata come obiettivo | Da dimostrare con budget e prove | V0.1 |
| DEC-007 | Frequenzimetro, wattmetro, ROS e modulometro | Confermata | Misure da calibrare | V0.1 |
| DEC-008 | Accordatore automatico con bypass | Confermata | Rete LC RF e protezioni da dimensionare | V0.1 |
| DEC-009 | PCB SMD ove tecnicamente appropriato | Confermata | Eventuali eccezioni motivate | V0.1 |
| DEC-010 | Assemblaggio previsto tramite PCBWay | Confermata | Richiederà DFM/BOM/posizionamenti compatibili | V0.1 |
| DEC-011 | Produzione documentazione cumulativa a ogni milestone | Confermata | ZIP intero, changelog, stato, verifiche | V0.1.1 |
| DEC-012 | Quattro fascicoli manuale finali e rapporti di collaudo | Confermata | Indici presenti, contenuto ancora in lavorazione | V0.1.1 |
| DEC-013 | RX 270, TX soggetto a limitazioni di legge e conformità | Vincolo preliminare | TX interbloccato anche via hardware | V0.1 |
| DEC-014 | PCB 4 layer, struttura modulare | Da validare | Potrebbero servire più schede o stack-up diverso | V0.1 |
| DEC-015 | Montaggio esterno identico all'originale | Da decidere | Servono telaio, forature, foto e misure | V0.1 |

Quando si cambia una decisione: aggiungere un record di modifica e indicare gli elaborati dipendenti da aggiornare.

## Decisioni/valutazioni introdotte in V0.2
- **D-020 (ipotesi di progetto, REVERSIBILE):** prima FI 10,695MHz, LO high-side da 36,310 a 39,000MHz, possibile seconda FI 455kHz per AM/FM.
- **D-021 (candidato non approvato):** ADF4351 SMD in Integer-N, 12,8MHz TCXO, R=20, PFD=640kHz, feedback VCO fondamentale, uscita /64, N=3631..3900. Misura phase-noise/spurie prima della scelta definitiva.
- **D-022 (candidato non approvato):** mixer primo stadio Mini-Circuits ADE-1+; LO +7dBm richiesto, prevedere buffer dopo filtro LO, matching da verificare.
- **D-023 (architettura di prova):** attenuazione RF selezionabile 0/10/20dB, LNA bypass, preselettori di banda, doppio sensore proposto ai lati dell'ATU.
- **D-024 (validato SOLO software):** modello CH9 (AM prioritaria) + ALFA fisico + interlock logico TX fail-closed: richiede scheda hardware e firmware collaudati prima di trasmettere.

## V0.4, decisioni provvisorie
- D-021 (PROVVISORIA) Filtro d'anello R2/C2,C1,R3/C3 6.8n/1.2k/120n/270R/4.7n su modello PFD+VCO linearizzato; non approvato per produzione.
- D-022 (PROVVISORIA) ADL5611 come buffer LO candidato: l'intervallo 36-39MHz e' incluso nella specifica. PHA-1+ rimosso dalla rosa primaria (min 50MHz).
- D-023 (APERTA) Qualificare rumore di fase e reciprocal mixing prima di approvare ADF4351; verifica importante ad fPFD=640kHz/N circa 3750.
- D-024 (APERTA) TCXO T200F-012.8M favorito SOLO per accuratezza, non approvato senza datasheet phase-noise e modello.

- **DEC-05, 2026-11-06, PROVVISORIA:** scegliere LMX2572 quale opzione principale di sintesi a basso rumore; non dismettere ADF4351. Motivazione: figure of merit bianco normalizzato di -232 anziche' -220 dBc/Hz e fPFD 1.28 anziche' 0.64 MHz, vantaggio modellato ~15.01 dB solo IN-BAND, con 270 canali esatti in Integer-N. Condizioni: progetto nuovo filtro d'anello, prova phase noise/spurie VCO/reference/buffer, verifica hardware prima di chiudere lo schema.

### V0.6 - 2026-11-06
- LMX2572 resta candidato principale, non approvato per PCB. Nuovo filtro di terzo ordine a valori ipotetici, vietato riciclare valori ADF.
- TCXO TXC 7N-12.800MBP-T candidato; selezione non vincolante finche non si verifica il phase noise e il datasheet originale.
- In VCO nominali TI, primo e secondo canale banda A sotto 4.65 GHz => core VCO3; tutti gli altri => core VCO4. Usare autocalibrazione, non forzare core.
- Interlock TX previsto se synthesizer unlock.

### DEC-V09-01 - due LDO separati (2026-11-06)
BOZZA: U2 3V3_PLL, U3 3V3_REF; entrambi da 5V pre-regolati. Non permettere ingresso 13.8V su TPS7A20.
### DEC-V09-02 - riferimento CMOS (2026-11-06)
BOZZA: Y1 TXC 7N 12.8MHz, LMX2572 OSCinP AC-coupled, OSCinM NC, pin10 e footprint bloccanti.


## V1.1 - 2026-11-06
- CW e PA aggiunti alla baseline dei requisiti; non ancora implementati.
- TPS26600PWPT scelto come candidato eFuse per il solo ramo ausiliario 5V, con nodi GND e RTN separati; fuses/TVS e controllo fault aperti.
- Schema KiCad di studio, non sottoposto a ERC. Non inviare a PCBWay.
