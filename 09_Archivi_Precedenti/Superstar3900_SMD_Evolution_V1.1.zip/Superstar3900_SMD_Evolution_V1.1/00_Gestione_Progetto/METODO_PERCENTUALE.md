# Metodo dell'avanzamento

L'avanzamento e una STIMA, non un risultato di conformita e nemmeno una previsione di durata.
La scala e 0-100% con completamento raggiunto soltanto quando sono pronti
progetto fabbricabile, schemi, BOM, PCB, file PCBWay, firmware, collaudi di prototipo
e manuali richiesti. Ogni settore contribuisce con un peso fisso; la quota raggiunta
e soggettiva e prudenziale, con blocchi in attesa delle verifiche.

In V0.8: **18% arrotondato** (17,54% calcolato).
L'assenza di ERC KiCad, di PCB, di simulazioni RF affidabili e di misure reali
impedisce di considerare una parte consistente del progetto completata.

La stima e aggiornata dopo ciascuna revisione; l'incremento puo anche essere zero
o negativo se emergono errori e viene ritirata una scelta progettuale.

## V0.9
Avanzamento secondo stessi pesi: 18.89% arrotondato **19%**. Incremento rispetto a V0.8: +1 punto nominale. Solo stima documentale, non certificazione tecnica.

## V1.0
Stessi pesi fissi. Incremento dello stato PLL/riferimento/LO per definizione del core 5V (39% -> 46%), specifiche 75% -> 77%, manuali 5% -> 8%. Nessun credito di validazione hardware, ERC o layout. Avanzamento 20% arrotondato.


## V1.1
Pesi invariati; specifiche 80%, PLL/alimentazione 48%, TX/PA 1% (solo requisiti), manuali 10%. Totale **20.99%** stimato, 21% arrotondato. La percentuale puo scendere se emergono correzioni.
