# Superstar 3900 SMD Evolution - archivio cumulativo V1.1

Data: 2026-11-06 | **STATO: BOZZA, NON FABBRICABILE**

**Avanzamento complessivo stimato: 20.99% -> 21% arrotondato.**

## Novita

1. eFuse TI TPS26600PWPT per il ramo **ausiliario** 13.8V / 5V, studio di circuito con riferimenti TI, pin map e scheda KiCad modificabile **DRAFT**. Blocchi F200 e D200 da dimensionare; D200 non montato.
2. Requisiti CW e PA formalizzati (non implementati).
3. Distinzione *obbligatoria* EFUSE_RTN vs GND_MAIN.
4. Calcoli delle soglie riproducibili e registro verifiche.

## File
- `04_KiCad/Sorgenti_Protezione_Ingresso_V1.1/S3900E_EFUSE_TPS26600_V1_1_DRAFT.kicad_sch`
- `04_KiCad/Sorgenti_Protezione_Ingresso_V1.1/Netlist_Intenzionale_TPS26600_V1.1.csv`
- `07_Componenti/BOM_Protezione_TPS26600_V1.1_BOZZA.csv`
- `01_Specifiche/Protezioni_Ingresso_V1.1.md` e `01_Specifiche/CW_PA_Requisiti_V1.1.md`
- `03_Verifiche/Report_Protezione_V1.1.json` e `test_efuse_v11.py`
- `06_Manuali/Dossier_Tecnico_V1.1.pdf`
- `00_Gestione_Progetto/RIPRENDI_IN_UNA_NUOVA_CHAT.md`

## Stato tecnico
Nessun ERC KiCad nativo, DRC, SPICE, PCB, prototipo o misura. TCXO pin10 e footprint non risolti. Le altre funzioni non sono schemi pronti. Non ordinare.

## Storia
La V1.0 completa e inclusa come ZIP sotto `09_Archivi_Precedenti` e le sorgenti correnti sono copiati dalla precedente versione.
